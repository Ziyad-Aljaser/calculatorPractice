class Bag {
    color=null;
    length=0;
    meterial=null;

    Bag(){
        this.color=color;
        this.length=length;
        this.meterial=meterial
    }

    Bag(doubleTheLength){
        this.color=color;
        this.length=length*doubleTheLength;
        this.meterial=meterial
    }
}
